package com.finance.monthly_gold_investment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonthlyGoldInvestmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
