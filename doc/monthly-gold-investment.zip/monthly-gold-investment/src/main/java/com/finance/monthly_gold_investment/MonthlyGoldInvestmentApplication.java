package com.finance.monthly_gold_investment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonthlyGoldInvestmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonthlyGoldInvestmentApplication.class, args);
	}

}
